<!-- Drag and Drop: WordPress : PHP -->

<?php  

include 'action.php';
echo "Today is : " . date("l");


?>