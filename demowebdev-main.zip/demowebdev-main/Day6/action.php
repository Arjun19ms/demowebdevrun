<?php  

echo "Today is : " . date("Y.m.d");


?>