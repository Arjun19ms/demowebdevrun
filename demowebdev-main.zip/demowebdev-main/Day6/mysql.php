

<!-- SQL Statements -->
<!-- MySQL Workbench -->

<!-- PHPmyAdmin / SQLyog-->


<!-- 1. create database internship; -->
<!-- 2. use intership; -->
<!-- 3. Create table students(name varchar(255), email varchar(255), phone int(64)); -->
<!-- 4. Select * from students; -->